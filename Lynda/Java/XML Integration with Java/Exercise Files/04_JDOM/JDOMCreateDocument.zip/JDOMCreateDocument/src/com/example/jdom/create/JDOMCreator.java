package com.example.jdom.create;

public class JDOMCreator {

	@SuppressWarnings("unused")
	private static final String XMLDATEFORMAT = "yyyy-MM-dd'T'HH:mm:ss";

	public JDOMCreator() {
	}
	
}
