package com.example.jdom.read;

import java.util.ArrayList;
import java.util.List;

import com.example.model.Customer;

public class JDOMReader {

	@SuppressWarnings("unused")
	private static final String XMLDATEFORMAT = "yyyy-MM-dd'T'HH:mm:ss";

	public List<Customer> getDataFromXML(String filename) {

		List<Customer> data = new ArrayList<>();

		return data;

	}

}
