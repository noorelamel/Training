package com.example.dom.create;

public class DOMCreator {

	@SuppressWarnings("unused")
	private static final String XMLDATEFORMAT = "yyyy-MM-dd'T'HH:mm:ss";

	public DOMCreator() {
	}

}
