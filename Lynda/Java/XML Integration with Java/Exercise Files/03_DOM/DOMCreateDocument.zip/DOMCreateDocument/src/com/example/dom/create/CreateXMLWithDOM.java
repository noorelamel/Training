package com.example.dom.create;

public class CreateXMLWithDOM {

	public static void main(String[] args) {

	}

}
