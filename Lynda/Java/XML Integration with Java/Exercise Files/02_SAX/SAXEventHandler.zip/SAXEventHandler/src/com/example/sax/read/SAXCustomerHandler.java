package com.example.sax.read;

import java.util.List;

@SuppressWarnings("unused")
public class SAXCustomerHandler {

	private List<Customer> data;
	private static final String XMLDATEFORMAT = "yyyy-MM-dd'T'HH:mm:ss";

	public List<Customer> readDataFromXML(String filename) {
		
		return data;
	}
	
}
