package com.example.stax.create;

import java.util.List;

import com.example.model.Customer;

public class StAXStreamCreator {

	@SuppressWarnings("unused")
	private static final String XMLDATEFORMAT = "yyyy-MM-dd'T'HH:mm:ss";

	public void createDocument(List<Customer> data, String filename) {
	
	}

}
