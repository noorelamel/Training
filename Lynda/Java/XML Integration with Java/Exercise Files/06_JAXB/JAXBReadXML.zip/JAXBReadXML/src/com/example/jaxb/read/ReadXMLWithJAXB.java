package com.example.jaxb.read;

public class ReadXMLWithJAXB {
	
	public static void main(String[] args) {
	    
	}

}
